﻿"""Frozen-run launcher: transport integrity, two history probes, then 9+27 runs."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path.cwd()))
from datetime import datetime,timezone
from dataclasses import asdict
import ctypes,hashlib,json,os,threading,zipfile
from types import SimpleNamespace
from majority.llm import load_settings,open_client,prompt_hash
from majority.nonthinking import NonThinkingGuard
from scripts.majority_factorial import load_prepared,read_json,write_json
from scripts import majority_study as study
from scripts.main2_v2 import run_workflow

ROOT=Path(__file__).resolve().parent
TRANSPORT=read_json(ROOT/'transport_manifest.json')
STOP=threading.Event()
LOCK=threading.Lock()

def verify_transport():
    if STOP.is_set() or (ROOT/'transport_stop.json').exists():
        raise RuntimeError('Transport integrity stopped; review transport_stop.json')
    for entry in TRANSPORT['files']:
        path=Path(entry['live_path'])
        actual=hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
        if actual != entry['sha256']:
            with LOCK:
                STOP.set()
                if not (ROOT/'transport_stop.json').exists():
                    write_json(ROOT/'transport_stop.json',{'time':datetime.now(timezone.utc).isoformat(),
                        'file':path.name,'expected_sha256':entry['sha256'],'actual_sha256':actual})
            raise RuntimeError('Gateway plugin changed; no further dispatch')

class PinnedClient:
    def __init__(self,client):
        self.client=client
        self.chat=SimpleNamespace(completions=SimpleNamespace(create=self.create))
    def create(self,**kwargs):
        verify_transport()
        response=self.client.chat.completions.create(**kwargs)
        verify_transport()
        return response
    def close(self): self.client.close()

BASE_OPEN=open_client

def pinned_open(config,key):
    verify_transport()
    return PinnedClient(BASE_OPEN(config,key))

def preflight():
    report=ROOT/'preflight'/'result.json'
    if report.exists():
        raise RuntimeError('Preflight already exists; explicit recovery review required')
    report.parent.mkdir()
    manifest=load_prepared(ROOT)
    config,key=load_settings();config=study.study_llm_config(config)
    assert asdict(config)==manifest['protocol']['llm']
    chosen={}
    archive=Path.cwd()/'experiments/2026-11-25-main2-v2/full/trajectories'
    for path in sorted(archive.glob('*.zip')):
        with zipfile.ZipFile(path) as z,z.open('calls.jsonl') as lines:
            for line in lines:
                row=json.loads(line)['data'];context=row.get('context',{});round_number=context.get('round')
                if row.get('status')!='ok' or round_number not in (5,10) or context.get('schema_attempt',0)!=0:
                    continue
                size=len(json.dumps(row['payload'],ensure_ascii=False))
                if round_number not in chosen or size>chosen[round_number][0]:chosen[round_number]=(size,path.name,row)
    assert set(chosen)=={5,10}
    guard=NonThinkingGuard(ROOT/'nonthinking_stop.json')
    results=[]
    for round_number in [5,10]:
        size,source,row=chosen[round_number];payload=row['payload']
        assert prompt_hash('perception')==row['prompt_sha256']
        allowed={m['id'] for exp in [*payload['history'],payload['current']] for m in [*exp['messages'],*exp['context']]}
        def parse(d):
            if set(d)!={'support','reason','evidence_ids'}:raise ValueError('Wrong fields')
            if type(d['support']) not in (int,float) or not 0<=d['support']<=1:raise ValueError('Invalid support')
            if not isinstance(d['reason'],str) or not 1<=len(d['reason'].strip())<=120:raise ValueError('Invalid reason')
            ids=d['evidence_ids']
            if not isinstance(ids,list) or len(ids)>5 or any(not isinstance(x,str) for x in ids) or len(set(ids))!=len(ids) or not set(ids)<=allowed:raise ValueError('Invalid evidence IDs')
            return d
        log=report.parent/f'round{round_number}_calls.jsonl'
        client=pinned_open(config,key)
        try:
            with log.open('x',encoding='utf-8') as audit:
                chat=study.StudyChat(client,config,audit,nonthinking_guard=guard)
                print(f'PREFLIGHT round={round_number} input_characters={size}',flush=True)
                parsed,completion=chat._request_once('perception',payload,parse,temperature=0,
                    context={'run_id':'long-history-preflight','node':row['context']['node'],'round':round_number})
            last=json.loads(log.read_text(encoding='utf-8').splitlines()[-1])['data']
            results.append({'round':round_number,'source_archive':source,'input_characters':size,
                'elapsed_seconds':completion.elapsed_seconds,'input_tokens':completion.input_tokens,
                'output_tokens':completion.output_tokens,'nonthinking_check':last.get('nonthinking_check'),'schema_valid':True})
            print('PREFLIGHT PASS '+json.dumps(results[-1]),flush=True)
        finally:client.close()
    write_json(report,{'status':'passed','config':asdict(config),'samples':results,'counts_as_experiment':False})

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'preflight'
    if mode not in ('preflight','run'):raise ValueError('Choose preflight or run')
    verify_transport()
    # Temporary execution-state request; no permanent power settings are changed.
    if os.name=='nt':ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    try:
        if mode=='preflight':preflight()
        else:
            result=read_json(ROOT/'preflight/result.json')
            if result['status']!='passed':raise RuntimeError('Preflight not passed')
            manifest=load_prepared(ROOT)
            config,_=load_settings();assert asdict(study.study_llm_config(config))==result['config']==manifest['protocol']['llm']
            study.open_client=pinned_open
            print('STARTING 9 PILOTS THEN REMAINING 27; shared nonthinking guard and transport hash pinning enabled',flush=True)
            run_workflow(ROOT)
    except Exception as exc:
        status=ROOT/f'{mode}_failure.json'
        if not status.exists():write_json(status,{'time':datetime.now(timezone.utc).isoformat(),'error_type':type(exc).__name__})
        raise
    finally:
        if os.name=='nt':ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
